To build:

`npm run benchmark:build`

Watch can cause issues with 0x as it's watching the SIGINT/SIGTERM

To run:
`npm run benchmark:run`