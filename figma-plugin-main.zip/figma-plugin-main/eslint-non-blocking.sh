#!/bin/bash
eslint . --quiet --fix; exit 0