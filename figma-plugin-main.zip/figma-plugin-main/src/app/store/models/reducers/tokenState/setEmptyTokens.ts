import type { TokenState } from '../../tokenState';

export function setEmptyTokens(state: TokenState): TokenState {
  return state;
}
