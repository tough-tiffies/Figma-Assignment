import type { TokenState } from '../../tokenState';

export function setDefaultTokens(state: TokenState): TokenState {
  return state;
}
