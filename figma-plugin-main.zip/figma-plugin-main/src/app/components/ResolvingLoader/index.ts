import { ResolvingLoader } from './ResolvingLoader';

export default ResolvingLoader;
