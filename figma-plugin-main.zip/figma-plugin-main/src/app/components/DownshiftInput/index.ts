import { DownshiftInput } from './DownshiftInput';

export default DownshiftInput;
