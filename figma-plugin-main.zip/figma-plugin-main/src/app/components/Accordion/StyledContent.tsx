import { styled } from '@/stitches.config';

export const StyledContent = styled('div', {
  overflow: 'hidden',
  gridColumn: '2',
  gridRow: '2',
});
