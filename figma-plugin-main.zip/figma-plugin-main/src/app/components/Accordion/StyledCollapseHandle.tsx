import { styled } from '@/stitches.config';

export const StyledCollapseHandle = styled('div', {
  gridColumn: '1',
  gridRow: '1',
});
