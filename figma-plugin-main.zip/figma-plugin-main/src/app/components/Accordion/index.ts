import { Accordion } from './Accordion';

export default Accordion;
