import { styled } from '@/stitches.config';

export const StyledForm = styled('form', {
  marginBottom: 0,
});
