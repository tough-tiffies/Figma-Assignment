import { styled } from '@/stitches.config';
import { Flex } from '../Flex';

export const StyledCreateOrEditThemeFormTabsFlex = styled(Flex, {
  marginLeft: 'auto',
});
