import { styled } from '@/stitches.config';

export const ErrorValidation = styled('div', {
  color: '$dangerFg',
  fontWeight: '$bold',
});
