export enum ApplicationInitSteps {
  SAVE_PLUGIN_DATA = 'save-plugin-data',
  ADD_LICENSE = 'add-license',
  GET_LD_FLAGS = 'get-ld-flags',
  SAVE_STORAGE_INFORMATION = 'save-storage-information',
  PULL_TOKENS = 'pull-tokens',
}
