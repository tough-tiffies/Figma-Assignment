import { ColorDisplayBubble } from './ColorDisplayBubble';

export default ColorDisplayBubble;
